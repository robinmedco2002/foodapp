export const LOGIN_TOKEN = "login";
export const APP_URL = "http://localhost:9000/";