import React from "react";

export default function AboutUs(){
    return(
        <h2 className="hjk">About Us</h2>
    )
}