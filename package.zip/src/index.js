import ReactDOM from "react-dom";
import * as React from "react";
import {App} from "./App";
import "./index.css";
// import "bootstrap/dist/js/bootstrap";

ReactDOM.render(React.createElement(App), document.querySelector("#app"));
